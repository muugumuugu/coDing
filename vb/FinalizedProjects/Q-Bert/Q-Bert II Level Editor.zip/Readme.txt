This is the Level Editor for Q-bert II.
Table Of Contents:
1) Introduction
2) Visit & contact

---------------------------------
-				-
-	   Introduction         -
-				-
---------------------------------
Q-Bert II Level Editor is the utility that allows you to make levels for Q-Bert II.
No explaination of the code is included because it's not as complicated as Q-Bert II,
and most of the code is used in Q-Bert II, too.
for more levels and updates on Q-Bert II, see the Damadros Web-site
http://www.damadros.cjb.net

---------------------------------
-				-
- 	 Visit & contact        -
-				-
---------------------------------
For more games, plans, utilities, webapps, and much more, visit the Damadros Web-site:
http://damadros.cjb.net
To contact me (on the Damadros site you can find my addresses, too):
drmayerson@lycos.co.uk