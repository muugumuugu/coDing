Title: electronic keyboard ( organ)
Description: press the keys and hear the different note from pc internal speaker.you can play music like piano.
this code work in 
win 95,98,me .I promise next time to write the code for windows 2000 .in this coe I use port address of internal pc speaker.plese vote it.thank you.
(YOU MUST COPY "INPOUT.DLL" to directory "windows\system" and "windows\system32" or 
in run type regsvr32 path\inpout32.dll

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=31153&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
