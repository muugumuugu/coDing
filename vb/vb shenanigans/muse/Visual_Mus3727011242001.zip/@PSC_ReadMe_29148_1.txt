Title: Visual Music
Description: This application is the fruit of frustration that I came across with usual mechanical software jobs. I decided to write perfact application but didn't exist the way it was supposed to. And so here's the Visual Music. Includes thousands of lines of cool VB code, graphics, very detailed Microsoft styled on-line help for user and InstallShield wizard script. Here's what it does:
Visual Music lets you play 128 instruments on your PC including Flute, Bagpiper and even whistle! You can even record what you are playing, edit it and save it in a file. If you not expert at playing synthesiser keyboard, it provides you a easy to use scripting language to create music just by telling what key in which instrument you want to play for how much time!

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=29148&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
