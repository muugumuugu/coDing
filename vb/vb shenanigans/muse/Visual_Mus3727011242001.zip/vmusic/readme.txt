Visual Music 1.1


How to run
---------
Visual Music.exe.


Where's complete docs?
-------------------------
Visual Music.chm


What is it about?
-----------------
Visual Music lets you play 128 instruments on your PC including Flute, Bagpiper and even whistle! You can even record what you are playing, edit it and save it in a file. If you not expert at playing synthesiser keyboard, it provides you a easy to use scripting language to create music just by telling what key in which instrument you want to play for how much time!


Where's web site?
-------------------
Visit Visual Music's home page at http://www.ShitalShah.com/vmusic


Who did it?
-----------
Visual Music is designed and developed by,
Shital Shah.
Email: shital_s@usa.net
Homepage: http://www.ShitalShah.com
�Shital Shah, 25 July 1999.

This program is freeware. Source code included.