Title: reate music from pictures - 6 different midi songs from a single picture
Description: Create music from pictures - 6 different midi songs from a single picture
This code creates music from any picture, although you can implement it to create midi music from files too. You can change the existing picture to any picture of your choice. This can be pretty useful in encryption. But there may be other uses of it also What is technique behind this? This program does nothing but takes a pixel splits it into R, G & B and then uses the facility provided by free OCX "FreeLib" to create midi music. I have zipped that OCX. The value of R, G & B can be Instrument, Volume or Note. Thus creating 6 different types of music. However, the music produced is not much interesting. I coded this when I was bored and I wrote the code. Please give comments, critics and Please VOTE!!!
Made By
Paras Chopra
CEO, NaramCheez
paraschopra@lycos.com
http://naramcheez.netfirms.com
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=36317&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
